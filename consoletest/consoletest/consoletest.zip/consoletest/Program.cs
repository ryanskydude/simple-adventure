﻿using System;

namespace consoletest
{
    public static class Game {

        public static void StartGame()
        {
            String title = @"

 _____ _                 _      
/  ___(_)               | |     
\ `--. _ _ __ ___  _ __ | | ___ 
 `--. \ | '_ ` _ \| '_ \| |/ _ \
/\__/ / | | | | | | |_) | |  __/
\____/|_|_| |_| |_| .__/|_|\___|
                  | |           
                  |_|           
  ___      _                 _                  
 / _ \    | |               | |                 
/ /_\ \ __| |_   _____ _ __ | |_ _   _ _ __ ___ 
|  _  |/ _` \ \ / / _ \ '_ \| __| | | | '__/ _ \
| | | | (_| |\ V /  __/ | | | |_| |_| | | |  __/
\_| |_/\__,_| \_/ \___|_| |_|\__|\__,_|_|  \___|";

            Console.ForegroundColor = ConsoleColor.Red;
            //this is the code for the title big man
            Console.WriteLine(title);
            Console.ResetColor();
            Console.WriteLine("By SamuraiWeebR");
            Console.WriteLine("This is A Very Basic Game.");
            Console.WriteLine("DISCLAIMER: This is game is really simple. i doubt you will enjoy it. \n do you accept the fact that this game could be quick or crap?");
            string userResponse = Console.ReadLine();
            //eula to tell someone to fuck off if they gonna judge
            if (userResponse == "Yes")
            {
                Console.WriteLine("Then enjoy the experience.");
            }
            else if (userResponse == "No" || userResponse == "no")
            {
                Console.WriteLine("Then Go Away.");
                Environment.Exit(5);
            }
            //here comes the fun part
            Console.WriteLine("What is your name?");
            string characterName = Console.ReadLine();
            Console.WriteLine("Your Name is " + characterName + "!");
            Console.WriteLine("What is your age?");
            var characterAge = Convert.ToInt16(Console.ReadLine());
            if (characterAge < 18)
            {
                Console.WriteLine("You can't be UnderAge!");
                return;
            }
            else if(characterAge > 18)
            {
                Console.WriteLine("Your Age is " + characterAge + "!");
            }
            //game starts now.
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Cyan;
            double armorToughness = 0.1;
            double attackDamage = 10.50 - armorToughness;
            double enemyAttack = 5.00;
            double enemyHP = 20.00;
            double playerHP = 20.00;
            Console.WriteLine("You Enter the Temple, It's Walls shining a blue hue. 'my first quest' you thought, as you entered. what do you do?");
            string userAction = Console.ReadLine();
            if(userAction == "walk" || userAction == "run")
            {
                Console.WriteLine("you move deeper into the temple, when suddenly, a goblin appears! what will you do?");
            }
            userAction = Console.ReadLine();
            armorToughness = 2.5;
            if (userAction == "Attack" || userAction == "attack")
            {
                Console.WriteLine("You attack the Goblin for " + attackDamage + "!");
                enemyHP = enemyHP - attackDamage;
                Console.WriteLine("He has " + enemyHP + " hp left!");
            }
            else if(userAction == "run" || userAction == "run away")
            {
                Console.WriteLine("the Goblin stops you from running. you are cornered!");
                Console.WriteLine("The Goblin hits you with his dagger!");
                    playerHP = playerHP - enemyAttack;
                Console.WriteLine("you have " + playerHP + " HP left!");
            }

        }
    }
    class Item { 
    }
    class MainClass
    {
        public static void Main(string[] args)
        {
            Game.StartGame();
            Console.WriteLine("The Game has Shut Down. if your seeing this, it probably crashed.");
            Console.ReadKey();
        }
    }
}
